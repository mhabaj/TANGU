var class_log =
[
    [ "__construct", "class_log.html#a424ff9c7cdfbda288905fbac7e20b6ba", null ],
    [ "close", "class_log.html#aa69c8bf1f1dcf4e72552efff1fe3e87e", null ],
    [ "getFilePointer", "class_log.html#a920308bfd90102618703af4393ccab7c", null ],
    [ "open", "class_log.html#a44a2ac59a3b91f8c18905dce700934d6", null ],
    [ "write", "class_log.html#a1176b92f0b0e4b3a40514af0dbc55169", null ]
];