var class_connexion_b_d_d =
[
    [ "__construct", "class_connexion_b_d_d.html#a095c5d389db211932136b53f25f39685", null ],
    [ "__destruct", "class_connexion_b_d_d.html#a421831a265621325e1fdd19aace0c758", null ],
    [ "connect", "class_connexion_b_d_d.html#a78572828d11dcdf2a498497d9001d557", null ],
    [ "getCon", "class_connexion_b_d_d.html#a69d47b951343847eb872495590d43109", null ]
];