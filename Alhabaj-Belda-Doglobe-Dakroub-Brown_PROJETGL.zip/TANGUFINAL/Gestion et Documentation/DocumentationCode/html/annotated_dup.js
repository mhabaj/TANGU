var annotated_dup =
[
    [ "Arc", "class_arc.html", "class_arc" ],
    [ "Blason", "class_blason.html", "class_blason" ],
    [ "ConnexionBDD", "class_connexion_b_d_d.html", "class_connexion_b_d_d" ],
    [ "entrainement", "classentrainement.html", "classentrainement" ],
    [ "Log", "class_log.html", "class_log" ],
    [ "SerieController", "class_serie_controller.html", "class_serie_controller" ],
    [ "User", "class_user.html", "class_user" ]
];