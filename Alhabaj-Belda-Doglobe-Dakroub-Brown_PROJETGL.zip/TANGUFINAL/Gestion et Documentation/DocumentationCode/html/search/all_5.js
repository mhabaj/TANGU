var searchData=
[
  ['getarcid',['getArcID',['../class_arc.html#adb077e034d792d322f95da431879663e',1,'Arc']]],
  ['getblasonid',['getBlasonID',['../class_blason.html#a96b6dda0a842d67dbb65e6b8b8dd6206',1,'Blason']]]
];
