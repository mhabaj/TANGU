var indexSectionsWithContent =
{
  0: "_abceglsu",
  1: "abcelsu",
  2: "_cgs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions"
};

