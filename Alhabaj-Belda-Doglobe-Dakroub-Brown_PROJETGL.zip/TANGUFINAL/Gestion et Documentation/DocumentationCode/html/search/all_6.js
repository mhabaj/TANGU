var searchData=
[
  ['log',['Log',['../class_log.html',1,'']]]
];
