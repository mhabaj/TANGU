var searchData=
[
  ['seriecontroller',['SerieController',['../class_serie_controller.html',1,'']]]
];
