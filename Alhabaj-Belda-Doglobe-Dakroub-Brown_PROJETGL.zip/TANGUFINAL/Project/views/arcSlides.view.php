<div class="swiper-container" id="contentBox">
    <div class="swiper-wrapper">
        <div class="container swiper-slide" id="e1">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e2">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e3">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e4">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e5">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e6">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e7">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e8">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e9">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e10">
            <h3>Nom arc</h3>
        </div>
        <div class="container swiper-slide" id="e11">
            <h3>Nom arc</h3>
        </div>
    </div>
    <div class="swiper-pagination"></div>
</div>