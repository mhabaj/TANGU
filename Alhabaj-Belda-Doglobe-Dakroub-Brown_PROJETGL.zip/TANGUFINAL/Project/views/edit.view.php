<div class="container-fluid" id="mainBox">
    <div class="container-fluid content" id="contentBox">
        <div id="arcBox">
            <button type="button" id="arcButton" onclick="window.location='editArc.php'">
                <!---<a href="editArc.php"><h3>ARCS</h3></a>-->
                <h3>ARCS</h3>
            </button>
        </div>
        <div id="blasonBox">
            <button type="button" id="blasonButton" onclick="window.location='editBlason.php'">
                <!--<a href="editBlason.php"><h3>BLASONS</h3></a>-->
                <h3>BLASONS</h3>
            </button>
        </div>
    </div>
    <?php include_once 'includes/footer.php';?>
</div>
