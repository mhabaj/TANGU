<div class="container-fluid" id="mainBox">
    <?php include_once 'includes/header.php';?>
    <?php include_once 'includes/footer.php';?>
</div>

