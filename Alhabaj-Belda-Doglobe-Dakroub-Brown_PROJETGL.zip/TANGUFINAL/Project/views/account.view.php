
        <div class="container-fluid" id="mainBox">
            <?php include_once 'includes/header.php';?>
            <div id="title">
                <h3>Mes Infos</h3>
            </div>
            <div class="container-fluid" id="buttonsBox">
                <div id="button1">
                    <button id="pseudoBtn">
                        <a href="pseudo.php"><p>Pseudo</p></a>
                    </button>
                </div>

                <div id="button2">
                    <button id="passwordBtn">
                        <a href="password.php"><p>Mot de Passe</p></a>
                    </button>
                </div>
                <div id="button3">
                    <button id="logoutBtn">
                        <a href="deconnexion.php"><p>Me Déconnecter</p></a>
                    </button>
                </div>
            </div>
            <?php include_once 'includes/footer.php';?>
        </div>
