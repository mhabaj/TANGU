<div class="container-fluid header" id="headerBox">
    <div id="titleBox">
        <h1><?= $title?></h1>
    </div>
</div>