<?php
/**
 * Created by PhpStorm.
 * User: windf
 * Date: 11/11/2018
 * Time: 02:07
 */

$config = array(
    'driver' => 'mysql',
    'host' => 'localhost',
    'dbname' => 'tangubdd',
    'username' => 'root',
    'password' => ''
);